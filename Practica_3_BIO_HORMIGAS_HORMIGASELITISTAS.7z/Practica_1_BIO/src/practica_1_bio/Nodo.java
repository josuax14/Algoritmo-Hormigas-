/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_1_bio;

/**
 *
 * @author josev
 */
public class Nodo {
    double x;
    double y;
    double id;
    public Nodo(double xx,double yy, double idd)
    {
        x=xx;
        y=yy;
        id=idd;
    }

    public double getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public double getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public int distotropunto(Nodo aux)
    {
        return (int)Math.rint( Math.sqrt(Math.pow((x-aux.getX()),2)+ Math.pow((y-aux.getY()),2)));
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o); //To change body of generated methods, choose Tools | Templates.
    }
    
}
