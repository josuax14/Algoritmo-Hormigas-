/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_1_bio;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josev
 */
public class Practica_1_BIO {

    public static int semilla = 0;
    public static int capado = 0;
    public static ArrayList<Nodo> ciudad_coor = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        int opcion = -1;
        ArrayList<Nodo> nodos_alea = new ArrayList<Nodo>();
        ArrayList<Nodo> nodos = new ArrayList<Nodo>();

        System.out.println("Menu eleccion archivo: ");
        System.out.println("1 .- st70.tsp");
        System.out.println("2 .- ch130.tsp");
        System.out.println("3 .- a280.tsp");
        System.out.println("4 .- p654.tsp");
        System.out.println("5 .- vm1084.tsp");
        System.out.println("6 .- vm1748.tsp");
        Scanner eleccion = new Scanner(System.in);
        opcion = eleccion.nextInt();
        File f = null;
        switch (opcion) {
            case 1:
                f = new File("st70.tsp");
                break;
            case 2:
                f = new File("ch130.tsp");
                break;
            case 3:
                f = new File("a280.tsp");
                break;
            case 4:
                f = new File("p654.tsp");
                break;
            case 5:
                f = new File("vm1084.tsp");
                break;
            case 6:
                f = new File("vm1748.tsp");
                break;

        }

        //File f = new File("st70.tsp");
        //File f = new File("ch130.tsp");
        //File f = new File("a280.tsp");
        //File f = new File("p654.tsp");
        //File f = new File("vm1084.tsp");
        //File f = new File("vm1748.tsp");
        Scanner lector = new Scanner(f);
        double i = 0;
        // SALTAR 5 LINEAS INICIALES
        while (i < 6) {
            String line = lector.nextLine();
            i++;
        }

        while (lector.hasNext()) {

            Scanner sclinea = new Scanner(lector.nextLine());
            sclinea.useDelimiter(" ");

            String ini = sclinea.next();

            if (!ini.equals("EOF")) {
                double id = Double.parseDouble(ini);
                double x = Double.parseDouble(sclinea.next());
                double y = Double.parseDouble(sclinea.next());
                Nodo aux = new Nodo(x, y, id);
                nodos.add(aux);
            }
            sclinea.close();
        }
        ciudad_coor = (ArrayList<Nodo>) nodos.clone();

        //---
        /*System.out.println("Menu Elección Algoritmo: ");
        System.out.println("1 .- GRASP");
        System.out.println("2 .- GRASP Extendido");
        System.out.println("3 .- ILS");
        System.out.println("4 .- VNS");
         */
        int n = 0;
        if (opcion == 1) {
            n = 70;
        }
        if (opcion == 2) {
            n = 130;
        }
        if (opcion == 3) {
            n = 280;
        }
        if (opcion == 4) {
            n = 654;
        }
        if (opcion == 5) {
            n = 1084;
        }
        if (opcion == 6) {
            n = 1748;
        }

        Hormiga_Elitista(nodos, n);
        Hormiga(nodos, n);
        
        //System.out.println("Resultado Hormiga :" + Hormiga(nodos,n));
        for (int j = 0; j < 5; j++) {
            semilla++;
            /*System.out.println("Sol GRASP Normal " + GRASP(nodos, 1));
        System.out.println("Sol GRASP Extendido " + GRASP(nodos, 2));
        System.out.println("Sol ILS "+ILS(nodos,n));
        System.out.println("Sol VNS "+VNS(nodos,n));*/
        }
        /*
        double media = 0;
        ArrayList<Nodo> camino_mejor = null;
        int mejor_valor=0;
        for (int ii = 0; ii < 50; ii++) {
            
            nodos = algoritmo_aleatorio((ArrayList<Nodo>) nodos.clone());
            ArrayList<Nodo> auxicamino=PrimerMejor(Greedy((ArrayList<Nodo>) nodos.clone()));
            int auxi = camino(auxicamino);
            media = media + auxi;
            if(ii==0 )
            {
                camino_mejor=auxicamino;
                mejor_valor=auxi;
            }
            else
            {
                if(auxi < mejor_valor)
                {
                    camino_mejor=auxicamino;
                    mejor_valor=auxi;
                }
            }
            //System.out.println("Solucion GRASP: " + auxi);
            semilla++;
        }
        System.out.println("Mejor Solucion : "+mejor_valor);
                
        media = media / 50;
        System.out.println("Media = " + media);
         */

        //GRASP EXTENDIDO
        /*
        // ILS;
        Random  rn = new Random();
        int tamaño_problema = nodos.size();
        int tam_sub = tamaño_problema/4;
        
        nodos = algoritmo_aleatorio((ArrayList<Nodo>) nodos.clone());
        ArrayList<Nodo> camino_mejor = (ArrayList<Nodo>) nodos.clone();
        int mejor_valor=camino(camino_mejor);
        
        for(int j = 0;j<50;j++)
        {
            nodos=(ArrayList<Nodo>) PrimerMejor(nodos).clone();
            System.out.println("Camino actual = "+camino(nodos));
            int cam_Cal = camino(nodos);
            if(cam_Cal<mejor_valor)
            {
                mejor_valor=cam_Cal;
                camino_mejor=(ArrayList<Nodo>) nodos.clone();
            }
            
            //MUTACION
            int subgrupo = rn.nextInt(4)*17;
            ArrayList<Nodo> mezcla = new ArrayList<Nodo>();
            ArrayList<Nodo> comprueba = (ArrayList<Nodo>) nodos.clone();
            Nodo Corrupto = new Nodo(-1,-1,-1);
            comprueba.set(0,Corrupto);
            //System.out.println("Parametros for : subgrupo ="+subgrupo+" / subgrupo+tam_sub"+(subgrupo+tam_sub));
            for(int aa =subgrupo;aa<(subgrupo+tam_sub);aa++)
            {
                Nodo aux = new Nodo(nodos.get(aa).x,nodos.get(aa).y,nodos.get(aa).id);
                mezcla.add(aux);
            }
            
            //System.out.println("///////////////");
            //for(int auxi = 0;auxi<mezcla.size();auxi++) System.out.print(mezcla.get(auxi).id+"-");
            //System.out.println("");
            Collections.shuffle(mezcla);
            //for(int auxi = 0;auxi<mezcla.size();auxi++) System.out.print(mezcla.get(auxi).id+"-");
            
            //System.out.println("---------------");
            
            int iterador = subgrupo;
            
            for(int jj = 0;jj<mezcla.size();jj++)
            {
                Nodo aux = new Nodo(mezcla.get(jj).x,mezcla.get(jj).y,mezcla.get(jj).id);
                nodos.set(iterador,aux);
                iterador++;
            }
            
            boolean soniguales= true;
            for(int ii=0;ii<nodos.size();ii++)
            {
                //System.out.println("Par : nodos "+nodos.get(ii).id+" / comprueba "+comprueba.get(ii).id);
                if(nodos.get(ii).id != comprueba.get(ii).id) soniguales=false;
            }
            //if(soniguales==false) System.out.println("NO SON IGUALES");
            mezcla.clear();
            
            
      //      for(int g = 0;g<nodos.size();g++)
      //      {
      //          System.out.print(nodos.get(g).id+" | ");
      //      }
      //      System.out.println("");
            
                    
            
        }
        System.out.println("Mejor solucion = "+mejor_valor);
         */
 /*
        // VNS
        Random rn = new Random();
        int tamaño_problema = nodos.size();
        int tam_sub = tamaño_problema / 4;

        nodos = algoritmo_aleatorio((ArrayList<Nodo>) nodos.clone());
        ArrayList<Nodo> camino_mejor = (ArrayList<Nodo>) nodos.clone();
        int mejor_valor = camino(camino_mejor);
        System.out.println("Camino Inicial = " + mejor_valor);
        int cuenta_evaluaciones = 0;
        for (int x = 0; x < 50; x++) {
            int k = 1;
            while (k <= 5) {
                ArrayList<Nodo> vecino = (ArrayList<Nodo>) camino_mejor.clone();
                //mutacion de n8 -> a mayor k mayor amplitud
                generarvecino(vecino, k);
                // BUSQUEDA LOCAL
                // 32*camino_mejor.size()
                if (cuenta_evaluaciones < 5) {
                    vecino = ElMejor((ArrayList<Nodo>) vecino.clone());
                    cuenta_evaluaciones++;
                }
                int cam_vecino = camino(vecino);
                if (cam_vecino < mejor_valor) {
                    camino_mejor = (ArrayList<Nodo>) vecino.clone();
                    mejor_valor = cam_vecino;
                    k = 1;
                } else {
                    k++;
                }
            }
        }
        System.out.println("Mejor Sol = " + mejor_valor);
         */
    }

    public static int VNS(ArrayList<Nodo> nodos, int n) {
        Random rn = new Random();
        int tamaño_problema = nodos.size();
        int tam_sub = tamaño_problema / 4;

        nodos = algoritmo_aleatorio((ArrayList<Nodo>) nodos.clone());
        ArrayList<Nodo> camino_mejor = (ArrayList<Nodo>) nodos.clone();
        int mejor_valor = camino(camino_mejor);
        //System.out.println("Camino Inicial = " + mejor_valor);
        int cuenta_evaluaciones = 0;
        for (int x = 0; x < 50; x++) {
            int k = 1;
            while (k <= 5) {
                ArrayList<Nodo> vecino = (ArrayList<Nodo>) camino_mejor.clone();
                //mutacion de n8 -> a mayor k mayor amplitud
                generarvecino(vecino, k);
                // BUSQUEDA LOCAL
                // 32*camino_mejor.size()
                if (cuenta_evaluaciones < 5) {
                    vecino = ElMejor((ArrayList<Nodo>) vecino.clone(), n);
                    cuenta_evaluaciones++;
                }
                int cam_vecino = camino(vecino);
                if (cam_vecino < mejor_valor) {
                    camino_mejor = (ArrayList<Nodo>) vecino.clone();
                    mejor_valor = cam_vecino;
                    k = 1;
                } else {
                    k++;
                }
            }
        }
        return mejor_valor;

    }

    public static int ILS(ArrayList<Nodo> nodos, int n) {
        // ILS;
        Random rn = new Random();
        int tamaño_problema = nodos.size();
        int tam_sub = tamaño_problema / 4;

        nodos = algoritmo_aleatorio((ArrayList<Nodo>) nodos.clone());
        ArrayList<Nodo> camino_mejor = (ArrayList<Nodo>) nodos.clone();
        int mejor_valor = camino(camino_mejor);

        for (int j = 0; j < 50; j++) {
            nodos = (ArrayList<Nodo>) ElMejor(nodos, n).clone();
            //System.out.println("Camino actual = "+camino(nodos));
            int cam_Cal = camino(nodos);
            if (cam_Cal < mejor_valor) {
                mejor_valor = cam_Cal;
                camino_mejor = (ArrayList<Nodo>) nodos.clone();
            }

            //MUTACION
            int subgrupo = rn.nextInt(4) * 17;
            ArrayList<Nodo> mezcla = new ArrayList<Nodo>();
            ArrayList<Nodo> comprueba = (ArrayList<Nodo>) nodos.clone();
            Nodo Corrupto = new Nodo(-1, -1, -1);
            comprueba.set(0, Corrupto);
            //System.out.println("Parametros for : subgrupo ="+subgrupo+" / subgrupo+tam_sub"+(subgrupo+tam_sub));
            for (int aa = subgrupo; aa < (subgrupo + tam_sub); aa++) {
                Nodo aux = new Nodo(nodos.get(aa).x, nodos.get(aa).y, nodos.get(aa).id);
                mezcla.add(aux);
            }

            //System.out.println("///////////////");
            //for(int auxi = 0;auxi<mezcla.size();auxi++) System.out.print(mezcla.get(auxi).id+"-");
            //System.out.println("");
            Collections.shuffle(mezcla);
            //for(int auxi = 0;auxi<mezcla.size();auxi++) System.out.print(mezcla.get(auxi).id+"-");

            //System.out.println("---------------");
            int iterador = subgrupo;

            for (int jj = 0; jj < mezcla.size(); jj++) {
                Nodo aux = new Nodo(mezcla.get(jj).x, mezcla.get(jj).y, mezcla.get(jj).id);
                nodos.set(iterador, aux);
                iterador++;
            }

            boolean soniguales = true;
            for (int ii = 0; ii < nodos.size(); ii++) {
                //System.out.println("Par : nodos "+nodos.get(ii).id+" / comprueba "+comprueba.get(ii).id);
                if (nodos.get(ii).id != comprueba.get(ii).id) {
                    soniguales = false;
                }
            }
            //if(soniguales==false) System.out.println("NO SON IGUALES");
            mezcla.clear();

            //      for(int g = 0;g<nodos.size();g++)
            //      {
            //          System.out.print(nodos.get(g).id+" | ");
            //      }
            //      System.out.println("");
        }
        return mejor_valor;
    }

    public static int camino(ArrayList<Nodo> aux) {
        int dist_devuelta = 0;
        for (int i = 0; i < aux.size(); i++) {
            if (i != aux.size() - 1) {
                dist_devuelta = dist_devuelta + aux.get(i).distotropunto(aux.get(i + 1));
            } else {
                dist_devuelta = dist_devuelta + aux.get(i).distotropunto(aux.get(0));
            }
        }
        return dist_devuelta;
    }

    public static int caminoEntreCiudades(Nodo aux1, Nodo aux2) {

        return (int) Math.rint(Math.sqrt(Math.pow((aux1.x - aux2.getX()), 2) + Math.pow((aux1.y - aux2.getY()), 2)));
    }

    public static void pintacamino(ArrayList<Nodo> aux) {
        for (int i = 0; i < aux.size(); i++) {
            System.out.print(aux.get(i).id + "-");
        }
    }

    public static ArrayList<Nodo> BusquedaTabu(ArrayList<Nodo> camino_alea) {
        //ASOCIO EL MEJOR CAMINO AL ACTUAL
        int evaluaciones = 0;
        ArrayList<Nodo> mejor_camino = (ArrayList<Nodo>) camino_alea.clone();

        //CALCULO DE VARIABLES
        int tamañoproblema = camino_alea.size();
        int iteraciones = 0;
        int[][] matriz_frecuencia = new int[tamañoproblema][tamañoproblema];
        int tam_tabu = 2;
        ArrayList<Pares> Tabu = new ArrayList<Pares>();
        int itera_tabu = 0;
        for (int i = 0; i < tam_tabu; i++) {
            Tabu.add(new Pares(-1, -1));
        }
        while (iteraciones < tamañoproblema * 40) {

            int tamaño = camino_alea.size();
            Random r = new Random(semilla + iteraciones);
            ArrayList<Pares> pares = new ArrayList<Pares>();
            int i = 0;

            while (i < 40) {
                int elec1 = r.nextInt(tamaño);
                int elec2 = r.nextInt(tamaño);

                Pares aux = new Pares(elec1, elec2);

                if (comprobarsiestapar(pares, aux) == false) {
                    pares.add(aux);
                    i++;
                }
            }

            int MejorPar = -1;
            double MejorPar_Resultado = -1;
            int tamaño_recalculado = 0;
            int calc_camino = 0;

            for (int j = 0; j < 40; j++) {
                ArrayList<Nodo> cam_aux = (ArrayList<Nodo>) camino_alea.clone();
                calc_camino = camino(mejor_camino);
                evaluaciones++;

                Nodo pegar1 = new Nodo(camino_alea.get(pares.get(j).Nodo1).x, camino_alea.get(pares.get(j).Nodo1).y, camino_alea.get(pares.get(j).Nodo1).id);
                Nodo pegar2 = new Nodo(camino_alea.get(pares.get(j).Nodo2).x, camino_alea.get(pares.get(j).Nodo2).y, camino_alea.get(pares.get(j).Nodo2).id);

                cam_aux.set(pares.get(j).Nodo1, pegar2);
                cam_aux.set(pares.get(j).Nodo2, pegar1);

                tamaño_recalculado = camino(cam_aux);
                evaluaciones++;

                if (j == 0) {
                    MejorPar_Resultado = tamaño_recalculado;
                    MejorPar = j;
                } else {
                    if (MejorPar_Resultado > tamaño_recalculado) {
                        MejorPar_Resultado = tamaño_recalculado;
                        MejorPar = j;

                    }
                }
            }

            if (comprobarsiestapar(Tabu, pares.get(MejorPar)) == false) {
                //añadir a la tabu
                Nodo pegar1 = new Nodo(camino_alea.get(pares.get(MejorPar).Nodo1).x, camino_alea.get(pares.get(MejorPar).Nodo1).y, camino_alea.get(pares.get(MejorPar).Nodo1).id);
                Nodo pegar2 = new Nodo(camino_alea.get(pares.get(MejorPar).Nodo2).x, camino_alea.get(pares.get(MejorPar).Nodo2).y, camino_alea.get(pares.get(MejorPar).Nodo2).id);
                camino_alea.set(pares.get(MejorPar).Nodo1, pegar2);
                camino_alea.set(pares.get(MejorPar).Nodo2, pegar1);

                if (MejorPar_Resultado < calc_camino) {
                    mejor_camino = (ArrayList<Nodo>) camino_alea.clone();
                }

                matriz_frecuencia[pares.get(MejorPar).Nodo1][pares.get(MejorPar).Nodo2]++;
                matriz_frecuencia[pares.get(MejorPar).Nodo2][pares.get(MejorPar).Nodo1]++;
                Tabu.set(itera_tabu % tam_tabu, pares.get(MejorPar));
                itera_tabu++;

            } else {
                if (MejorPar_Resultado < calc_camino) {
                    //añadir a la tabu
                    Nodo pegar1 = new Nodo(camino_alea.get(pares.get(MejorPar).Nodo1).x, camino_alea.get(pares.get(MejorPar).Nodo1).y, camino_alea.get(pares.get(MejorPar).Nodo1).id);
                    Nodo pegar2 = new Nodo(camino_alea.get(pares.get(MejorPar).Nodo2).x, camino_alea.get(pares.get(MejorPar).Nodo2).y, camino_alea.get(pares.get(MejorPar).Nodo2).id);
                    camino_alea.set(pares.get(MejorPar).Nodo1, pegar2);
                    camino_alea.set(pares.get(MejorPar).Nodo2, pegar1);

                    mejor_camino = (ArrayList<Nodo>) camino_alea.clone();

                    matriz_frecuencia[pares.get(MejorPar).Nodo1][pares.get(MejorPar).Nodo2]++;
                    matriz_frecuencia[pares.get(MejorPar).Nodo2][pares.get(MejorPar).Nodo1]++;

                    Tabu.set(itera_tabu % tam_tabu, pares.get(MejorPar));
                    itera_tabu++;
                }
            }

            //PROBABILIDAD CADA 8N
            int menor_i = -5;
            int menor_j = -5;
            if ((iteraciones % (8 * tamañoproblema)) == 0) {
                double prob = Math.random();
                if (Math.random() < 0.5) {

                    for (int v = tam_tabu; v < tam_tabu * 2; v++) {
                        Tabu.add(new Pares(-1, -1));
                    }
                    tam_tabu = tam_tabu * 2;
                } else {
                    int tamañotabu = Tabu.size();
                    for (int v = tamañotabu; v < tam_tabu / 2; v--) {
                        Tabu.remove(v);
                    }
                    tam_tabu = tam_tabu / 2;
                }
                if (tam_tabu == 1) {
                    tam_tabu = 2;
                }

                if (prob < 0.25) {
                    //reset aleatorio del camino
                    camino_alea = algoritmo_aleatorio(camino_alea);
                } else if (prob < 0.5) {
                    camino_alea = (ArrayList<Nodo>) mejor_camino.clone();
                } else {

                    int valor_min = -5;
                    for (int iii = 0; iii < 70; iii++) {
                        for (int jjj = 0; jjj < iii; jjj++) {
                            if (iii == 1 && jjj == 0) {
                                menor_i = iii;
                                menor_j = jjj;
                                valor_min = matriz_frecuencia[iii][jjj];
                            }
                            if (valor_min >= matriz_frecuencia[iii][jjj]) {
                                menor_i = iii;
                                menor_j = jjj;
                                valor_min = matriz_frecuencia[iii][jjj];
                            }

                        }
                    }
                    Nodo pegar1 = new Nodo(camino_alea.get(menor_i).x, camino_alea.get(menor_i).y, camino_alea.get(menor_i).id);
                    Nodo pegar2 = new Nodo(camino_alea.get(menor_j).x, camino_alea.get(menor_j).y, camino_alea.get(menor_j).id);
                    camino_alea.set(menor_i, pegar2);
                    camino_alea.set(menor_j, pegar1);

                }
            }

            iteraciones++;

        }
        System.out.println("Evaluaciones : " + evaluaciones);
        return mejor_camino;
    }

    public static boolean comprobarsiestapar(ArrayList<Pares> pares, Pares aux) {
        boolean esta = false;
        for (int i = 0; i < pares.size(); i++) {
            if (aux.Nodo1 == pares.get(i).Nodo1) {
                if (aux.Nodo2 == pares.get(i).Nodo2) {
                    esta = true;
                }
            }
            if (aux.Nodo2 == pares.get(i).Nodo1) {
                if (aux.Nodo1 == pares.get(i).Nodo2) {
                    esta = true;
                }
            }

        }

        if (aux.Nodo1 == aux.Nodo2) {
            esta = true;
        }
        return esta;
    }

    public static ArrayList<Nodo> algoritmo_aleatorio(ArrayList<Nodo> nodos) {

        //ALGORITMO ALEATORIO
        ArrayList<Nodo> nodos_alea = new ArrayList<Nodo>();
        Random ini = new Random(semilla);

        int distancia = 0;
        int elec_ini = ini.nextInt(nodos.size());
        Nodo inicial = nodos.get(elec_ini);
        nodos_alea.add(inicial);
        nodos.remove(elec_ini);
        Nodo Actual = inicial;
        Nodo Final = null;

        while (!nodos.isEmpty()) {
            int dist_aux = 0;

            Random rnd = new Random();
            int elecrnd = rnd.nextInt(nodos.size());
            Nodo cmp = nodos.get(elecrnd);
            if (nodos.size() == 1) {
                Final = nodos.get(0);
                nodos_alea.add(Final);
            } else {
                nodos_alea.add(cmp);
            }
            dist_aux = Actual.distotropunto(cmp);

            distancia = distancia + dist_aux;
            Actual = nodos.get(elecrnd);
            nodos.remove(elecrnd);

        }
        return nodos_alea;
    }

    public static ArrayList<Nodo> Greedy(ArrayList<Nodo> nodos) {
        int evaluaciones = 0;
        //ALGORITMO KRUSKAL
        ArrayList<Nodo> kruskal = new ArrayList<Nodo>();
        Random ini = new Random(semilla);
        int elec_ini = ini.nextInt(nodos.size());

        int distancia = 0;
        Nodo inicial = nodos.get(elec_ini);
        kruskal.add(inicial);
        nodos.remove(elec_ini);
        Nodo Actual = inicial;
        Nodo Final = null;

        while (!nodos.isEmpty()) {
            int eleccion = 0;
            int dist_aux = 0;
            double longitud = nodos.size();

            for (int j = 0; j < longitud; j++) {
                Nodo cmp = nodos.get(j);
                if (j == 0) {
                    eleccion = j;
                    dist_aux = Actual.distotropunto(cmp);
                } else {
                    int distasoc = Actual.distotropunto(cmp);
                    if (distasoc < dist_aux) {
                        eleccion = j;
                        dist_aux = distasoc;

                    }
                }

            }
            distancia = distancia + dist_aux;
            Actual = nodos.get(eleccion);
            kruskal.add(Actual);
            nodos.remove(eleccion);
            if (nodos.size() == 1) {
                Final = nodos.get(0);
            }

        }
        distancia = distancia + Final.distotropunto(inicial);
        return kruskal;

    }

    public static ArrayList<Nodo> PrimerMejor(ArrayList<Nodo> nodos) {

        int evaluaciones = 0;
        ArrayList<Nodo> nodos_copia = (ArrayList<Nodo>) nodos.clone();
        int tama = nodos_copia.size();

        Random rnd = new Random(semilla);
        int contador = 0;
        int tamaño_actual = camino(nodos);
        evaluaciones++;
        boolean todobuscado = false;
        while (contador < 5000 && todobuscado == false) {

            int eleccion_ciudad = rnd.nextInt(tama);
            int punt = 0;
            boolean cond = false;
            while (cond != true && punt < tama) {
                if (nodos.get(eleccion_ciudad).id != nodos.get(punt).id) {
                    Nodo pegar = new Nodo(nodos.get(eleccion_ciudad).x, nodos.get(eleccion_ciudad).y, nodos.get(eleccion_ciudad).id);
                    Nodo pegar2 = new Nodo(nodos.get(punt).x, nodos.get(punt).y, nodos.get(punt).id);

                    nodos_copia.set(punt, pegar);
                    nodos_copia.set(eleccion_ciudad, pegar2);

                    int tamaño_recalculado = camino(nodos_copia);
                    evaluaciones++;
                    if (tamaño_recalculado < tamaño_actual) {
                        nodos = (ArrayList<Nodo>) nodos_copia.clone();
                        tamaño_actual = tamaño_recalculado;
                        cond = true;
                    } else {
                        nodos_copia = (ArrayList<Nodo>) nodos.clone();
                    }

                }
                punt++;
                if (punt == tama - 1) {
                    todobuscado = true;
                }
            }
            contador++;

        }
        return nodos;
    }

    public static ArrayList<Nodo> ElMejor(ArrayList<Nodo> nodos, int n) {
        int evaluaciones = 0;
        ArrayList<Nodo> nodos_copia = (ArrayList<Nodo>) nodos.clone();
        int tama = nodos_copia.size();

        Random rnd = new Random(semilla);
        int contador = 0;
        int tamaño_actual = camino(nodos);
        while (contador < 32 * n) {

            evaluaciones++;
            int eleccion_ciudad = rnd.nextInt(tama);
            int punt = 0;
            while (punt < tama) {
                if (nodos.get(eleccion_ciudad).id != nodos.get(punt).id) {
                    Nodo pegar = new Nodo(nodos.get(eleccion_ciudad).x, nodos.get(eleccion_ciudad).y, nodos.get(eleccion_ciudad).id);
                    Nodo pegar2 = new Nodo(nodos.get(punt).x, nodos.get(punt).y, nodos.get(punt).id);

                    nodos_copia.set(punt, pegar);
                    nodos_copia.set(eleccion_ciudad, pegar2);
                    //
                    if (contador < 32 * n) {
                        int tamaño_recalculado = camino(nodos_copia);
                        evaluaciones++;
                        if (tamaño_recalculado < tamaño_actual) {
                            nodos = (ArrayList<Nodo>) nodos_copia.clone();
                            tamaño_actual = tamaño_recalculado;
                        } else {
                            nodos_copia = (ArrayList<Nodo>) nodos.clone();

                        }
                    }

                }
                punt++;
            }
            contador++;
        }
        return nodos;
    }

    public static ArrayList<Nodo> EnfriaminetoSimulado(ArrayList<Nodo> nodos) {
        int evaluaciones = 0;
        int tama = nodos.size();

        Random rnd = new Random(semilla);

        int dist_actual = camino(nodos);
        evaluaciones++;
        double tita = 0.3;
        int num_iteracion = 20;

        double temperatura = (tita / -Math.log10(tita)) * dist_actual;
        double temperatura_aux = temperatura;
        int cuenta = 0;
        int cuenta_maximo = 80 * tama; //80

        while (temperatura_aux >= 0 && cuenta < cuenta_maximo) {

            for (int j = 0; j < num_iteracion; j++) {
                ArrayList<Nodo> nodos_copia = (ArrayList<Nodo>) nodos.clone();
                int ciudad1 = rnd.nextInt(nodos.size());
                int ciudad2 = rnd.nextInt(nodos.size());

                Nodo aux1 = new Nodo(nodos.get(ciudad1).x, nodos.get(ciudad1).y, nodos.get(ciudad1).id);
                Nodo aux2 = new Nodo(nodos.get(ciudad2).x, nodos.get(ciudad2).y, nodos.get(ciudad2).id);
                nodos_copia.set(ciudad2, aux1);
                nodos_copia.set(ciudad1, aux2);

                int camino_recalculado = camino(nodos_copia);
                evaluaciones++;
                int sol = camino_recalculado - dist_actual;
                double exponencial = Math.exp(-sol / temperatura_aux);
                double prob = Math.random();
                if (prob < exponencial || sol < 0) {
                    nodos = (ArrayList<Nodo>) nodos_copia.clone();
                    dist_actual = camino(nodos);
                    evaluaciones++;
                }

            }
            temperatura_aux = temperatura / (1 + cuenta);
            cuenta++;

        }
        System.out.println("Evaluaciones= " + evaluaciones);
        return nodos;
    }

    private static void generarvecino(ArrayList<Nodo> cam, int k) {

        Random rnd = new Random(semilla);
        int tamaño_mutacion = 9 - k;
        int size = cam.size();
        int tam_bloque = size / tamaño_mutacion;
        int ciudad_ini = rnd.nextInt(size - tam_bloque);
        Collections.shuffle(cam.subList(ciudad_ini, (ciudad_ini + tam_bloque)));
    }

    //GRASP--------------------------------------------------------------------------
    public static int GRASP(ArrayList<Nodo> puntos, int tipo) { // tipo 1 normal, tipo 2 extendido
        ArrayList<Nodo> p_clone = (ArrayList<Nodo>) puntos.clone();
        //CASCA AQUI ABAJO
        int Dist_ini = greedyProbabilistico(p_clone, tipo);

        int i = 0, convergencia = 50;
        int capado = 0;
        int Dist_act = Integer.MAX_VALUE;

        //System.out.println("ANTES WHILE");
        while (i < convergencia) {
            Dist_act = busquedaMejorRandom(p_clone, tipo);
            // System.out.println("Dist_act "+Dist_act);
            if (Dist_act < Dist_ini) {
                Dist_ini = Dist_act;
                //System.out.println("mejoro");
            }

            i++;
        }
        semilla++;

        //System.out.println("Mejor de todo encontrado " + Dist_ini);
        return Dist_ini;
    }

    public static int greedyProbabilistico(ArrayList<Nodo> puntos, int tipo) {//ArrayList<Punto>
        Random alea = new Random(semilla);

        int distancia = 0;
        int numevaluaciones = 0;
        ArrayList<Nodo> p_clone = (ArrayList<Nodo>) puntos.clone();
        ArrayList<Nodo> p_clone2 = new ArrayList<Nodo>();
        ArrayList<Pares> LRC = new ArrayList<Pares>();
        ArrayList<Pares> TODOS = new ArrayList<Pares>();
        int numalea = alea.nextInt(p_clone.size());
        Nodo inicial = p_clone.get(numalea);

        int sum = 0;
        p_clone.remove(numalea);
        Nodo Actual = inicial;
        Nodo Final = null;

        while (!p_clone.isEmpty()) {
            //System.out.println("p_CLONE SIZE : "+p_clone.size());
            int eleccion = 0;
            int dist_aux = 0;
            double longitud = p_clone.size();
            Pares a = null;
            for (int j = 0; j < longitud; j++) {
                Nodo cmp = p_clone.get(j);
                a = new Pares(cmp, Actual, cmp.distotropunto(Actual));
                if (j == 0) {
                    eleccion = j;
                    dist_aux = a.getDistancia();

                } else {
                    int distasoc = a.getDistancia();
                    if (distasoc < dist_aux) {

                        TODOS = CaminosPosibles(j, p_clone);
                        // System.out.println("Todosss "+TODOS.size());
                        int num = (int) (0.1 * p_clone.size());
                        LRC = MejoresCaminos(num, TODOS, p_clone);
                        //System.out.println("lrc size " + LRC.size());
                        if (LRC.size() > 0) {
                            if (tipo == 1) {
                                eleccion = alea.nextInt(LRC.size());
                                dist_aux = LRC.get(eleccion).getDistancia();
                            } else if (tipo == 2) {
                                int numLRC = LRC.size();
                                int total = 1;
                                for (int k = 0; k < numLRC; k++) {
                                    int prob = 1 / LRC.get(k).getDistancia();
                                    total *= LRC.get(k).getDistancia();
                                }
                                for (int k = 0; k < numLRC; k++) {
                                    sum += (total / LRC.get(k).getDistancia());
                                }

                                for (int k = 0; k < numLRC; k++) {
                                    if (k == 0) {
                                        int dis = LRC.get(k).getDistancia();
                                        float calculo = (float) dis / (float) sum;
                                        LRC.get(k).setProb(calculo);
                                    } else {
                                        int dis = LRC.get(k).getDistancia();
                                        float calculo = (float) dis / (float) sum;
                                        LRC.get(k).setProb(calculo);
                                        LRC.get(k).setProb(calculo + LRC.get(k - 1).getProb());
                                    }

                                }

                                double prob_unif = Math.random();
                                int k = 0;
                                boolean encontrado = false;
                                while (k < numLRC && encontrado == false) {
                                    if (prob_unif >= LRC.get(k).getProb()) {
                                        eleccion = k;
                                        dist_aux = LRC.get(eleccion).getDistancia();
                                        encontrado = true;
                                    }
                                    k++;
                                }
                            }
                        } else {
                            eleccion = j;
                            dist_aux = distasoc;
                            //p_clone2.add(p_clone.get(eleccion));
                        }

                    }
                }

            }
            distancia = distancia + dist_aux;
            numevaluaciones++;
            Actual = p_clone.get(eleccion);
            p_clone2.add(Actual);

            // System.out.println("ACTUAL --- "+Actual.getPunto());
            //System.out.println("ARRAYYY --- "+p_clone2.get(p_clone2.size()-1).getPunto());
            p_clone.remove(eleccion);
            if (p_clone.size() == 1) {
                Final = p_clone.get(0);
                p_clone2.add(Final);
            }
            // System.out.println("p_colone 2 "+p_clone2.size());
        }

        Pares a = new Pares(inicial, Final, inicial.distotropunto(Final));

        distancia = distancia + a.getDistancia();
        //seed++;
        //System.out.println("Numero evaluaciones " + numevaluaciones);
        // System.out.println("Distancia  "+ distancia);
        // System.out.println("Distancia calculada de camino "+calculoDistanciaNuevo(p_clone2, caminos));
        return distancia;
        // return p_clone2;
    }

    public static ArrayList<Pares> CaminosPosibles(int p, ArrayList<Nodo> puntos) {
        ArrayList<Pares> TODOS = new ArrayList<Pares>();

        for (int i = p + 1; i < puntos.size(); i++) {
            Pares a = new Pares(puntos.get(p), puntos.get(i), puntos.get(p).distotropunto(puntos.get(i)));
            //System.out.println("a ---- "+a.toString());
            TODOS.add(a);
        }
        for (int i = p - 1; i >= 0; i--) {
            Pares a = new Pares(puntos.get(p), puntos.get(i), puntos.get(p).distotropunto(puntos.get(i)));
            //System.out.println("a ---- "+a.toString());
            TODOS.add(a);
        }

        return TODOS;

    }

    public static ArrayList<Pares> MejoresCaminos(int num, ArrayList<Pares> TODOS, ArrayList<Nodo> ciudades) {
        ArrayList<Pares> LRC = new ArrayList<Pares>();
        Pares mejor = TODOS.get(0);
        TODOS.remove(0);

        for (int i = 0; i < num; i++) {
            for (int j = 0; j < TODOS.size(); j++) {
                Pares comparar = TODOS.get(j);

                if (mejor.getDistancia() > comparar.getDistancia()) {
                    mejor = comparar;
                    TODOS.remove(j);
                }
            }
            if (!LRC.contains(mejor)) {
                LRC.add(mejor);
            }
        }

        /*for(int i=0;i<LRC.size();i++)
            System.out.println(" "+LRC.get(i).toString());*/
        return LRC;
    }

    public static void twoOptNew(ArrayList<Nodo> p_clone, int num_alea, int num_alea2) {
        Nodo aux = new Nodo(p_clone.get(num_alea).x, p_clone.get(num_alea).y, p_clone.get(num_alea).id);
        p_clone.set(num_alea, p_clone.get(num_alea2));
        p_clone.set(num_alea2, aux);
    }

    public static int busquedaMejorRandom(ArrayList<Nodo> puntos, int tipo) {
        //// FALTA BUCLE
        Random alea = new Random(semilla);
        int numevaluaciones = 0;
        ArrayList<Nodo> p_clone = (ArrayList<Nodo>) puntos.clone();
        //int Dist = calculoDistanciasINI(p_clone);
        int Dist = greedyProbabilistico(p_clone, tipo);
        int DistActual = Integer.MAX_VALUE;
        numevaluaciones++;
        int n = p_clone.size();
        int i = 0;
        int convergencia = 32 * puntos.size();
        while (i < convergencia) {
            //System.out.println("i "+i);
            int num_alea = alea.nextInt(n);
            int num_alea2 = alea.nextInt(n);
            twoOptNew(p_clone, num_alea, num_alea2);
            if (capado < 32 * puntos.size()) {
                DistActual = camino(p_clone);
                capado++;
                numevaluaciones++;
            }
            if (Dist >= DistActual) {
                Dist = DistActual;

                //System.out.println("Distancia cambiada: " + Dist);
            } else {
                twoOptNew(p_clone, num_alea2, num_alea);
            }

            //  System.out.println("numero de iteracion ---- " + i);
            i++;

        }
        //System.out.println("Numero evaluaciones " + numevaluaciones);
        return Dist;
    }

    private static int Hormiga(ArrayList<Nodo> nodos, int tam_matrix) {
        semilla++;
        float alpha = (float) 1; //PRIORIDAD FEROMONA
        float beta = (float) 2; //PRIORIDAD DISTANCIA
        float p = (float) 0.1;
        
        float caminomejor = camino(nodos);
        //System.out.println("Camino mejor inicial = "+caminomejor);
        int convergencia = 20000;

        ArrayList<Nodo> ciudades = (ArrayList<Nodo>) nodos.clone();
        int[][] distancias = new int[tam_matrix][tam_matrix];

        //CUIDADO EL ID 1 ES EL 0
        for (int q = 0; q < tam_matrix; q++) {
            for (int w = 0; w < tam_matrix; w++) {
                if (q != w) {
                    distancias[q][w] = buscar_nodo_por_id(ciudades, q + 1).distotropunto(buscar_nodo_por_id(ciudades, w + 1));
                
                    if(distancias[q][w]==0) distancias[q][w]=1;
                }
            }
        }

        System.out.println("Tabla de Distancia Creada");
       
        ArrayList<Nodo> camino_inicial = Greedy(nodos);
        int L = camino(camino_inicial);
        float[][] tabla_feromonas = new float[tam_matrix][tam_matrix];
        float auxi = tam_matrix * L;
        float valor_inicialicacion = 1 / auxi;

        System.out.println("valor_inicializacion= "+valor_inicialicacion);
        for (int xx = 0; xx < tam_matrix; xx++) {
            for (int yy = 0; yy < tam_matrix; yy++) {
                tabla_feromonas[xx][yy] = valor_inicialicacion;
            }
        }

        int i = 0;
        Random rnd = new Random(semilla);

        while (i < convergencia) {
            ArrayList<ArrayList> caminos_de_hormigas = new ArrayList<ArrayList>();
            for (int h = 0; h < 20; h++) {

                ArrayList<Nodo> ciudades_hormiga = (ArrayList) camino_inicial.clone();
                ArrayList<Nodo> camino_Elegido = new ArrayList<Nodo>();

                int ciudad_inicio = rnd.nextInt(ciudades_hormiga.size()); // DESDE 0 A 69 (ID-1)
                //System.out.println("CIUDAD PARA EMPEZAR = "+ciudad_inicio);
                for (int u = 0; u < ciudades_hormiga.size(); u++) {
                    if (ciudades_hormiga.get(u).id - 1 == ciudad_inicio) {
                        //System.out.println("Elimino la primera");
                        camino_Elegido.add(ciudades_hormiga.remove(u));
                    }
                }

                while (ciudades_hormiga.isEmpty() != true) {
                    //System.out.println("-----------------------------tamanio : "+ciudades_hormiga.size());
                    double sumprob = 0;

                    //System.out.println("Ciudad Inicio = "+ciudad_inicio);
                    for (int aux = 0; aux < tam_matrix; aux++) {
                        if (ciudad_inicio != aux && estadentro(ciudades_hormiga, aux)) {
                            //System.out.println("Ciudad_inicio ITERACION= "+aux+" Ciudad: "+ciudad_inicio);
                            //System.out.println("sumprob antes="+sumprob);
                            sumprob += (Math.pow(tabla_feromonas[ciudad_inicio][aux], alpha) * Math.pow(1f/distancias[ciudad_inicio][aux], beta));
                            //System.out.println("sumprob despues="+sumprob);
                        }

                    }
                    

                    //System.out.println("SALGO Cuentaveces= "+cuentaveces);
                    double rnd_hormiga = getRandom(0.0, sumprob);

                    //System.out.println("rnd_hormiga eleccion: "+rnd_hormiga+" sumprob= "+sumprob);
                    
                    int elec_sig_ciudad = -1;
                    boolean encontrado_elecc = false;
                    int aux = 0;
                    //System.out.println("Prob Total: "+sumprob+" | Prob Tocada: "+rnd_hormiga);

                    //System.out.println("Primera Probabilidad");
                    //&& aux < tam_matrix
                    while ( encontrado_elecc == false ) {
                        int pos = 0;
                        for (int k = 0; k < ciudades_hormiga.size(); k++) {
                            if (ciudades_hormiga.get(k).id-1 == aux) {
                                pos = k;
                            }
                        }
                        
                        if (ciudad_inicio != aux && estadentro(ciudades_hormiga, aux)) {
                            //System.out.println("rnd_hormiga: "+rnd_hormiga);
                            rnd_hormiga -= ((Math.pow(tabla_feromonas[ciudad_inicio][aux], alpha) * Math.pow(1f/distancias[ciudad_inicio][aux], beta)));
                            //System.out.println("Ciudad aux ="+aux+" / rnd hormiga = "+rnd_hormiga);
                        }

                        if (rnd_hormiga < 0) {
                            elec_sig_ciudad = (int) ciudades_hormiga.get(pos).id - 1;
                            //System.out.println("elec_sig_ciudad = "+elec_sig_ciudad);
                            encontrado_elecc = true;
                        }
                        aux++;
                        
                    }
                    //System.out.println("SALIDA DE PROBABILIDADES");
                    

                    ciudad_inicio = elec_sig_ciudad;
                    //System.out.println("CIUDAD DEPSUES DE ELECCION = "+ciudad_inicio);

                    for (int u = 0; u < ciudades_hormiga.size(); u++) {

                        if (ciudades_hormiga.get(u).id - 1 == elec_sig_ciudad) {
                            //System.out.println("ELIMINO");
                            camino_Elegido.add(ciudades_hormiga.remove(u));
                        }
                    }
                    if (ciudades_hormiga.size() == 1) {
                        camino_Elegido.add(ciudades_hormiga.remove(0));
                    }

                }
                //añadir caminos para depsues ejecutar procesado de feromonas
                caminos_de_hormigas.add(camino_Elegido);
                //System.out.println("Camino de la hormiga="+camino(camino_Elegido));
            }

            //fase evaporacion y añadir feromonas
            //System.out.println("evapora antes = "+tabla_feromonas[1][3]);
            for (int iii = 0; iii < tam_matrix - 1; iii++) {
                for (int jjj = 0; jjj < tam_matrix; jjj++) {
                    if (iii != jjj) {
                        tabla_feromonas[iii][jjj] = (1 - p) * tabla_feromonas[iii][jjj];
                    }
                }
            }
            //System.out.println("evapora despues = "+tabla_feromonas[1][3]);

            for (int ff = 0; ff < caminos_de_hormigas.size(); ff++) {
                int ind1 = 0;
                int ind2 = 0;
                ArrayList<Nodo> indicador_camino = caminos_de_hormigas.get(ff);
                int gg = 0;

                int caminito = camino(indicador_camino);
                //System.out.println("&&&&&&&&&&&&&&&&&&&&&&&66 caminomejor "+caminomejor);
                if(caminomejor>caminito){
                    caminomejor=caminito;
                    System.out.println("Mejor camino encontrado: "+caminomejor);
                }
                
                float resultado = (float) (1.0 / caminito);

                for (gg = 0; gg < caminos_de_hormigas.get(ff).size() - 1; gg++) {

                    ind1 = (int) (indicador_camino.get(gg).id - 1);
                    ind2 = (int) (indicador_camino.get(gg + 1).id - 1);
                    //System.out.println("MODIFICO A: "+tabla_feromonas[ind1][ind2]);

                    //System.out.println("RESULT = "+resultado);
                    tabla_feromonas[ind1][ind2] += resultado;
                    tabla_feromonas[ind2][ind1] += resultado;
                    //System.out.println("MODIFICO D: "+tabla_feromonas[ind1][ind2]);
                }
                tabla_feromonas[ind2][(int) indicador_camino.get(0).id - 1] += resultado;
                tabla_feromonas[(int) indicador_camino.get(0).id - 1][ind2] += resultado;

            }
 
            i++;
            //Scanner sc=new Scanner(System.in);
            //sc.nextLine();
        }
        return 0;
    }
    
    private static int Hormiga_Elitista(ArrayList<Nodo> nodos, int tam_matrix) {
        semilla++;
        float alpha = (float) 1; //PRIORIDAD FEROMONA
        float beta = (float) 2; //PRIORIDAD DISTANCIA
        float p = (float) 0.1;
        float caminomejor = camino(nodos);
        int convergencia = 20000;

        ArrayList<Nodo> ciudades = (ArrayList<Nodo>) nodos.clone();
        int[][] distancias = new int[tam_matrix][tam_matrix];

        //CUIDADO EL ID 1 ES EL 0
        for (int q = 0; q < tam_matrix; q++) {
            for (int w = 0; w < tam_matrix; w++) {
                if (q != w) {
                    distancias[q][w] = buscar_nodo_por_id(ciudades, q + 1).distotropunto(buscar_nodo_por_id(ciudades, w + 1));
                    if(distancias[q][w]==0) distancias[q][w]=1;
                }
            }
        }

        System.out.println("Tabla de Distancia Creada");
       
        ArrayList<Nodo> camino_inicial = Greedy(nodos);
        int L = camino(camino_inicial);
        float[][] tabla_feromonas = new float[tam_matrix][tam_matrix];
        float auxi = tam_matrix * L;
        float valor_inicialicacion = 1 / auxi;

        System.out.println("valor_inicializacion= "+valor_inicialicacion);
        for (int xx = 0; xx < tam_matrix; xx++) {
            for (int yy = 0; yy < tam_matrix; yy++) {
                tabla_feromonas[xx][yy] = valor_inicialicacion;
            }
        }

        int i = 0;
        Random rnd = new Random(semilla);

        while (i < convergencia) {
            ArrayList<ArrayList> caminos_de_hormigas = new ArrayList<ArrayList>();
            
            int hormiga_elitista=-1;
            int camino_elitista=-1;
            
            for (int h = 0; h < 20; h++) {

                ArrayList<Nodo> ciudades_hormiga = (ArrayList) camino_inicial.clone();
                ArrayList<Nodo> camino_Elegido = new ArrayList<Nodo>();

                int ciudad_inicio = rnd.nextInt(ciudades_hormiga.size()); // DESDE 0 A 69 (ID-1)
                //System.out.println("CIUDAD PARA EMPEZAR = "+ciudad_inicio);
                for (int u = 0; u < ciudades_hormiga.size(); u++) {
                    if (ciudades_hormiga.get(u).id - 1 == ciudad_inicio) {
                        //System.out.println("Elimino la primera");
                        camino_Elegido.add(ciudades_hormiga.remove(u));
                    }
                }

                while (ciudades_hormiga.isEmpty() != true) {
                    //System.out.println("-----------------------------tamanio : "+ciudades_hormiga.size());
                    double sumprob = 0;

                    //System.out.println("Ciudad Inicio = "+ciudad_inicio);
                    for (int aux = 0; aux < tam_matrix; aux++) {
                        if (ciudad_inicio != aux && estadentro(ciudades_hormiga, aux)) {
                            //System.out.println("Ciudad_inicio ITERACION= "+aux+" Ciudad: "+ciudad_inicio);
                            sumprob += (Math.pow(tabla_feromonas[ciudad_inicio][aux], alpha) * Math.pow(1f/distancias[ciudad_inicio][aux], beta));
                            
                        }

                    }
                    

                    //System.out.println("SALGO Cuentaveces= "+cuentaveces);
                    double rnd_hormiga = getRandom(0.0, sumprob);

                    //System.out.println("rnd_hormiga eleccion: "+rnd_hormiga+" sumprob= "+sumprob);
                    
                    int elec_sig_ciudad = -1;
                    boolean encontrado_elecc = false;
                    int aux = 0;
                    //System.out.println("Prob Total: "+sumprob+" | Prob Tocada: "+rnd_hormiga);

                    //System.out.println("Primera Probabilidad");
                    //&& aux < tam_matrix
                    while ( encontrado_elecc == false ) {
                        int pos = 0;
                        for (int k = 0; k < ciudades_hormiga.size(); k++) {
                            if (ciudades_hormiga.get(k).id-1 == aux) {
                                pos = k;
                            }
                        }
                        
                        if (ciudad_inicio != aux && estadentro(ciudades_hormiga, aux)) {
                            //System.out.println("rnd_hormiga: "+rnd_hormiga);
                            rnd_hormiga -= ((Math.pow(tabla_feromonas[ciudad_inicio][aux], alpha) * Math.pow(1f/distancias[ciudad_inicio][aux], beta)));
                            //System.out.println("Ciudad aux ="+aux+" / rnd hormiga = "+rnd_hormiga);
                        }

                        if (rnd_hormiga < 0) {
                            elec_sig_ciudad = (int) ciudades_hormiga.get(pos).id - 1;
                            //System.out.println("elec_sig_ciudad = "+elec_sig_ciudad);
                            encontrado_elecc = true;
                        }
                        aux++;
                        
                    }
                    //System.out.println("SALIDA DE PROBABILIDADES");
                    

                    ciudad_inicio = elec_sig_ciudad;
                    //System.out.println("CIUDAD DEPSUES DE ELECCION = "+ciudad_inicio);

                    for (int u = 0; u < ciudades_hormiga.size(); u++) {

                        if (ciudades_hormiga.get(u).id - 1 == elec_sig_ciudad) {
                            //System.out.println("ELIMINO");
                            camino_Elegido.add(ciudades_hormiga.remove(u));
                        }
                    }
                    if (ciudades_hormiga.size() == 1) {
                        camino_Elegido.add(ciudades_hormiga.remove(0));
                    }

                }
                //añadir caminos para depsues ejecutar procesado de feromonas
                caminos_de_hormigas.add(camino_Elegido);
                int camino_auxi=camino(camino_Elegido);
                if(hormiga_elitista==-1)
                {
                    hormiga_elitista=h;
                    camino_elitista=camino_auxi;
                    
                }else
                {
                    if(camino_auxi<camino_elitista)
                    hormiga_elitista=h;
                    camino_elitista=camino_auxi;
                }
            }

            //fase evaporacion y añadir feromonas
            
            for (int iii = 0; iii < tam_matrix - 1; iii++) {
                for (int jjj = 0; jjj < tam_matrix; jjj++) {
                    if (iii != jjj) {
                        tabla_feromonas[iii][jjj] = (1 - p) * tabla_feromonas[iii][jjj];
                    }
                }
            }
            //System.out.println("evapora despues = "+tabla_feromonas[1][3]);

            
            
            for (int ff = 0; ff < caminos_de_hormigas.size(); ff++) {
                float aporte_adicional_si_mejor_global=0;
                int ind1 = 0;
                int ind2 = 0;
                ArrayList<Nodo> indicador_camino = caminos_de_hormigas.get(ff);
                int gg = 0;

                int caminito = camino(indicador_camino);
                if(caminomejor>caminito){
                    caminomejor=caminito;
                    System.out.println("Mejor camino encontrado: "+caminomejor);
                    aporte_adicional_si_mejor_global=20*caminomejor;
                }
                
                float resultado = (float) (1.0 / caminito);

                int incremento=0;
                
                for (gg = 0; gg < caminos_de_hormigas.get(ff).size() - 1; gg++) {

                    ind1 = (int) (indicador_camino.get(gg).id - 1);
                    ind2 = (int) (indicador_camino.get(gg + 1).id - 1);
                    //System.out.println("MODIFICO A: "+tabla_feromonas[ind1][ind2]);

                    //System.out.println("RESULT = "+resultado);
                    tabla_feromonas[ind1][ind2] += resultado+aporte_adicional_si_mejor_global;
                    tabla_feromonas[ind2][ind1] += resultado+aporte_adicional_si_mejor_global;
                    //System.out.println("MODIFICO D: "+tabla_feromonas[ind1][ind2]);
                }
                tabla_feromonas[ind2][(int) indicador_camino.get(0).id - 1] += resultado+aporte_adicional_si_mejor_global;
                tabla_feromonas[(int) indicador_camino.get(0).id - 1][ind2] += resultado+aporte_adicional_si_mejor_global;

            }
 
            i++;
        }
        return 0;
    }

    public static double getRandom(Double valorMinimo, Double valorMaximo) {
        Random rand = new Random();
        return valorMinimo + (valorMaximo - valorMinimo) * rand.nextDouble();
    }

    public static boolean estadentro(ArrayList<Nodo> ciudades_hormiga, int a) {

        boolean esta = false;
        for (int i = 0; i < ciudades_hormiga.size(); i++) {
            if (ciudades_hormiga.get(i).id - 1 == a) {
                esta = true;
            }
        }

        return esta;
    }

    public static Nodo buscar_nodo_por_id(ArrayList<Nodo> ciudades, int a) {
        Nodo aux = null;
        for (int i = 0; i < ciudades.size(); i++) {
            if (ciudades.get(i).id == a) {
                aux = ciudades.get(i);
            }
        }

        return aux;
    }

}
