/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_1_bio;

import java.util.ArrayList;

/**
 *
 * @author josev
 */
public class Pares {
    int Nodo1;
    int Nodo2;
    float prob = 0;
    int distancia=0;
    
    public Pares(int n1,int n2)
    {
        Nodo1 = n1;
        Nodo2 = n2;
    }
    
    public Pares(Nodo n1,Nodo n2,int dis)
    {
        Nodo1=(int)n1.id;
        Nodo2=(int)n2.id;
        distancia=dis;
    }
    
    public int getDistancia()
    {
        /*
        //System.out.println("NODO1: "+Nodo1+" / NODO2: "+Nodo2);
        Nodo aux1=null;
        Nodo aux2=null;
        
        for(int i = 0;i<p_clone.size();i++)
        {
            //System.out.println("Ciudad: "+(int)p_clone.get(i).id);
            if(Nodo1 == (int)p_clone.get(i).id)
            {
                //System.out.println("N1");
                aux1 = new Nodo(p_clone.get(i).x,p_clone.get(i).y,p_clone.get(i).id);
            }
            
            if(Nodo2 == (int)p_clone.get(i).id)
            {
                //System.out.println("N2");
                aux2 = new Nodo(p_clone.get(i).x,p_clone.get(i).y,p_clone.get(i).id);
            }  
        }
        
        //System.out.println("Calcula Punto -> Nodo1: "+aux1.id+" / Nodo2: "+aux2.id);
                */
        return distancia;
    }
    
    public float getProb()
    {
        return prob;
    }
    
    public void setProb(float probi)
    {
        prob = probi;
    } 
}
